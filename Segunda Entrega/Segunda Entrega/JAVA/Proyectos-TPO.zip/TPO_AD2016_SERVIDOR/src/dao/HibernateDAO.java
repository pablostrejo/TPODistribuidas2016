package dao;

import hbt.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class HibernateDAO {

	protected static HibernateDAO instancia;
	protected static SessionFactory sessionFactory = null;
	protected static Session session = null;
	
	public static HibernateDAO getInstancia() {
		if (instancia == null) {
			sessionFactory = HibernateUtil.getSessionfactory();
			instancia = new HibernateDAO();
		}
		return instancia;
	}
	
	public Session getSession() {
		if (session == null || !session.isOpen()) {
			session = sessionFactory.openSession();
		}
		return session;
	}
	
	public void closeSession() {
		if (session.isOpen()) {
			session.close();
		}
	}
}
