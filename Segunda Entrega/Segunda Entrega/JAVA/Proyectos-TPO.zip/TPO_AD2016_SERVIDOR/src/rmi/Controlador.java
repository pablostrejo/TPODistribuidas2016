package rmi;

import hbt.HibernateUtil;

public class Controlador {

	public static void main(String[] args) {
		
		HibernateUtil test = new HibernateUtil();

	}

}
