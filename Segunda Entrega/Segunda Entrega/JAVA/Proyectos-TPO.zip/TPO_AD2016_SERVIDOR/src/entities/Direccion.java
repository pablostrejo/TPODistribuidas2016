package entities;

import javax.persistence.*;
import javax.persistence.Embeddable;
import javax.persistence.Entity;

import javax.persistence.Table;

@Entity
@Table (name = "Direcciones")
public class Direccion {
	
	@Id
	@GeneratedValue
	private int idDireccion;
	
	@Column (columnDefinition = "varchar(50)", nullable = true)
	private String calle;
	
	@Column (nullable = true)
	private int numero;
	
	@Column (nullable = true)
	private int piso;
	
	@Column (columnDefinition = "varchar(50)", nullable = true)
	private String departamento;
	
	@Column (columnDefinition = "varchar(50)", nullable = true)
	private String CP;

	public Direccion(){
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getPiso() {
		return piso;
	}

	public void setPiso(int piso) {
		this.piso = piso;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getCP() {
		return CP;
	}

	public void setCP(String cP) {
		CP = cP;
	}	
}
