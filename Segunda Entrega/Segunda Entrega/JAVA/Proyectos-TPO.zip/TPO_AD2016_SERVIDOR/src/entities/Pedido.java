package entities;

import java.sql.Date;
import java.util.List;

import javax.persistence.*;


@Entity
@Table (name = "Pedidos")
public class Pedido {
	
	@Id
	@GeneratedValue
	@Column (nullable = false)
	private int idPedido;
	
	@OneToOne
	@JoinColumn (name = "idDireccionCarga", referencedColumnName = "idDireccion")
	private Direccion direccionCarga;
	
	@OneToOne
	@JoinColumn (name = "idDireccionDestino", referencedColumnName = "idDireccion")
	private Direccion direccionDestino;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date fechaCarga;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date horaInicio;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date horaFin;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date fechaMaxima;
	
	@OneToMany
	@JoinColumn (name = "idCarga")
	private List<Carga> cargas;
	
	@Column (nullable = true)
	private float precio;
	
	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn (name = "idSucursal")
	private Sucursal sucursalDestino;
	
	@Column (columnDefinition = "bit", nullable = true)
	private boolean solicitaTransporteDirecto;
	
	@Column (columnDefinition = "bit", nullable = true)
	private boolean solicitaAvionetaParticular;
	
	@OneToOne
	@JoinColumn (name = "idCliente")
	private Cliente cliente;
	
	public Pedido() {
	}

	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}

	public Direccion getDireccionCarga() {
		return direccionCarga;
	}

	public void setDireccionCarga(Direccion direccionCarga) {
		this.direccionCarga = direccionCarga;
	}

	public Direccion getDireccionDestino() {
		return direccionDestino;
	}

	public void setDireccionDestino(Direccion direccionDestino) {
		this.direccionDestino = direccionDestino;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public Date getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Date horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Date getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public Date getFechaMaxima() {
		return fechaMaxima;
	}

	public void setFechaMaxima(Date fechaMaxima) {
		this.fechaMaxima = fechaMaxima;
	}

	public List<Carga> getCargas() {
		return cargas;
	}

	public void setCargas(List<Carga> cargas) {
		this.cargas = cargas;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public Sucursal getSucursalDestino() {
		return sucursalDestino;
	}

	public void setSucursalDestino(Sucursal sucursalDestino) {
		this.sucursalDestino = sucursalDestino;
	}

	public boolean isSolicitaTransporteDirecto() {
		return solicitaTransporteDirecto;
	}

	public void setSolicitaTransporteDirecto(boolean solicitaTransporteDirecto) {
		this.solicitaTransporteDirecto = solicitaTransporteDirecto;
	}

	public boolean isSolicitaAvionetaParticular() {
		return solicitaAvionetaParticular;
	}

	public void setSolicitaAvionetaParticular(boolean solicitaAvionetaParticular) {
		this.solicitaAvionetaParticular = solicitaAvionetaParticular;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
		
}
