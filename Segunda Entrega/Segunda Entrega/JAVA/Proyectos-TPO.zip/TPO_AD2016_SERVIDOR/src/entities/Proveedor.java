package entities;

import java.io.Serializable;
import javax.persistence.*;


@Entity
@Table (name = "Proveedores")
@Inheritance(strategy = InheritanceType.JOINED)
public class Proveedor implements Serializable {
	
	
	@Id
	@GeneratedValue
	@Column(name = "idProveedor", columnDefinition = "int", nullable=false)
	private int idProveedor;
	@Column(name="compania", columnDefinition = "varchar(50)", nullable=true)
	private String compania;
	@Column(name="tipoMercaderia", columnDefinition= "varchar(50)", nullable=true)
	private String tipoMercaderia;
	
	public Proveedor() {
		super();
	}
	
	public String getTipoMercaderia() {
		return tipoMercaderia;
	}
	public void setTipoMercaderia(String tipoMercaderia) {
		this.tipoMercaderia = tipoMercaderia;
	}
	public int getIdProveedor() {
		return idProveedor;
	}
	public void setIdProveedor(int idProveedor) {
		this.idProveedor = idProveedor;
	}
	public String getCompania() {
		return compania;
	}
	public void setCompania(String compania) {
		this.compania = compania;
	}
	
}
