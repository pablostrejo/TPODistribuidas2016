package entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table (name = "Viajes")
public class Viaje {

	@Id
	@GeneratedValue
	@Column (nullable = false)
	private int idViaje;
	
	@OneToMany (cascade = CascadeType.ALL)
	@JoinColumn (name = "idEnvio")
	private List<Envio> envios;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date fechaLlegada;
	
	@Column (columnDefinition = "bit", nullable = true)
	private boolean finalizado;
	
	@OneToOne
	@JoinColumn (name = "idVehiculo")
	private Vehiculo vehiculo;
	
	public Viaje() {
	
	}

	public int getIdViaje() {
		return idViaje;
	}

	public void setIdViaje(int idViaje) {
		this.idViaje = idViaje;
	}

	public List<Envio> getEnvios() {
		return envios;
	}

	public void setEnvios(List<Envio> envios) {
		this.envios = envios;
	}

	public Date getFechaLlegada() {
		return fechaLlegada;
	}

	public void setFechaLlegada(Date fechaLlegada) {
		this.fechaLlegada = fechaLlegada;
	}

	public boolean isFinalizado() {
		return finalizado;
	}

	public void setFinalizado(boolean finalizado) {
		this.finalizado = finalizado;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
}
