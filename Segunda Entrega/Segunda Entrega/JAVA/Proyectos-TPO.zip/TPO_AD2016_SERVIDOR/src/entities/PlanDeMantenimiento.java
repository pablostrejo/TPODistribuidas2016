package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "PlanesDeMantenimiento")
public class PlanDeMantenimiento {

	public PlanDeMantenimiento() {
		super();
	}
	@Id
	@GeneratedValue
	@Column(name = "idPlanDeMantenimiento", columnDefinition = "int", nullable=false)
	private int idPlanDeMantenimiento;
	@Column(name = "diasProxControl", columnDefinition = "int", nullable=true)
	private int diasProxControl;
	@Column(name = "diasDemora", columnDefinition = "int", nullable=true)
	private int diasDemora;
	@Column(name = "kmProxControl", columnDefinition = "int", nullable=true)
	private int kmProxControl;
	public int getDiasProxControl() {
		return diasProxControl;
	}
	public void setDiasProxControl(int diasProxControl) {
		this.diasProxControl = diasProxControl;
	}
	public int getDiasDemora() {
		return diasDemora;
	}
	public void setDiasDemora(int diasDemora) {
		this.diasDemora = diasDemora;
	}
	public int getKmProxControl() {
		return kmProxControl;
	}
	public void setKmProxControl(int kmProxControl) {
		this.kmProxControl = kmProxControl;
	}

	
}
