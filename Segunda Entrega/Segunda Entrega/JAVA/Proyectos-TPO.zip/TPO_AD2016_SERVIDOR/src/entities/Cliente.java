package entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table (name = "Clientes")
@Inheritance(strategy = InheritanceType.JOINED)
public class Cliente {
	
	@Id
	@Column(name = "idCliente", columnDefinition = "int", nullable=false)
	private int idCliente;
	
	@Column(name = "nombre", columnDefinition = "varchar(50)", nullable=true)
	private String nombre;

	public Cliente() {
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
