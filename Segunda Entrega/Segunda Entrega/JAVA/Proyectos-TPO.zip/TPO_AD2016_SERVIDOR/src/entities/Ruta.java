package entities;

import java.util.List;

import javax.persistence.*;

@Entity
@Table (name = "Rutas")
public class Ruta {

	
	@Id
	@GeneratedValue
	@Column(name = "idRuta", columnDefinition = "int", nullable=false)
	private int idRuta;
	@OneToMany
	@JoinColumn (name = "idTrayecto")
	private List<Trayecto> trayectos;
	
	@Column(name = "precio", columnDefinition = "float", nullable=true)
	private float precio;

	public Ruta() {
		super();
	}

	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}
	public int getIdRuta() {
		return idRuta;
	}
	public void setIdRuta(int idRuta) {
		this.idRuta = idRuta;
	}
	public List<Trayecto> getTrayectos() {
		return trayectos;
	}
	public void setTrayectos(List<Trayecto> trayectos) {
		this.trayectos = trayectos;
	}
}
