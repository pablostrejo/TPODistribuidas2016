package entities;

import java.util.List;

import javax.persistence.Column;

import javax.persistence.*;

import dto.ProductoDTO;

@Entity
@Table(name="Empresas")
public class Empresa extends Cliente{


	@Column(name="CUIT", columnDefinition= "int", nullable=true)
	private int CUIT;
	
	@Column(name="tipo", columnDefinition= "varchar(50)", nullable=true)
	private String tipo;
	
	@Column(name="detallePoliticas", columnDefinition= "varchar(50)", nullable=true)
	private String detallePoliticas;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "idCliente", referencedColumnName="idCliente")
	private List<Producto> productos;
	
	@Column(name="saldoCuentaCorriente", nullable=true)
	private float saldoCuentaCorriente;
	
	public Empresa() {
		super();
	}

	public int getCUIT() {
		return CUIT;
	}

	public void setCUIT(int cUIT) {
		CUIT = cUIT;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDetallePoliticas() {
		return detallePoliticas;
	}

	public void setDetallePoliticas(String detallePoliticas) {
		this.detallePoliticas = detallePoliticas;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public float getSaldoCuentaCorriente() {
		return saldoCuentaCorriente;
	}

	public void setSaldoCuentaCorriente(float saldoCuentaCorriente) {
		this.saldoCuentaCorriente = saldoCuentaCorriente;
	}
}
