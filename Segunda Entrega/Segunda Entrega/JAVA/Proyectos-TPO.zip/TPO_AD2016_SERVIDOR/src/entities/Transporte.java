package entities;


import javax.persistence.*;

@Entity
@Table(name="Transportes")
@DiscriminatorValue("Transportes")
public class Transporte extends Proveedor{

	public Transporte() {
		super();
	}
	private static final long serialVersionUID = 1L;
	@Column(name="tipoTransporte", columnDefinition= "varchar(50)", nullable=true)
	private String tipoTransporte;
	
}
