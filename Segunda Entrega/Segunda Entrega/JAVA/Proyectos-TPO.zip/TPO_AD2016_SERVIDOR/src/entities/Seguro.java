package entities;

import javax.persistence.*;

@Entity
@Table(name="Seguros")
public class Seguro extends Proveedor {

}
