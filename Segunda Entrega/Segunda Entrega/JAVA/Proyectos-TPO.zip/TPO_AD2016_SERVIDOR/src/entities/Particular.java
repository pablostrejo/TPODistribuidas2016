package entities;

import java.util.List;

import javax.persistence.*;

@Entity
@Table (name = "Particulares")
public class Particular extends Cliente {

	@Column (columnDefinition = "int", nullable = true)
	private int DNI;
	
	@Column (columnDefinition = "varchar(50)", nullable = true)
	private String apellido;
	
	@OneToMany (cascade = CascadeType.ALL)
	@JoinColumn (name = "idCliente")
	private List<Habilitado> habilitados;
	
	public Particular() {
		super();
	}

	public int getDNI() {
		return DNI;
	}

	public void setDNI(int dNI) {
		DNI = dNI;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public List<Habilitado> getHabilitados() {
		return habilitados;
	}

	public void setHabilitados(List<Habilitado> habilitados) {
		this.habilitados = habilitados;
	}
	
	
}
