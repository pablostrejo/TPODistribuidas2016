package entities;

import java.util.List;

import javax.persistence.*;

@Entity
@Table (name = "Sucursales")
public class Sucursal {

	@Id
	@GeneratedValue
	@Column (nullable = false)
	private int idSucursal;
	
	@Column (columnDefinition = "varchar(50)", nullable = true)
	private String nombre;
	
	@OneToOne
	@JoinColumn (name = "idDireccion")
	private Direccion ubicacion;
	
	@OneToMany (cascade = CascadeType.ALL)
	@JoinColumn (name = "idViaje")
	private List<Viaje> viajes;
	
	public Sucursal() {
		
	}

	public int getIdSucursal() {
		return idSucursal;
	}

	public void setIdSucursal(int idSucursal) {
		this.idSucursal = idSucursal;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Direccion getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(Direccion ubicacion) {
		this.ubicacion = ubicacion;
	}

	public List<Viaje> getViajes() {
		return viajes;
	}

	public void setViajes(List<Viaje> viajes) {
		this.viajes = viajes;
	}
}
