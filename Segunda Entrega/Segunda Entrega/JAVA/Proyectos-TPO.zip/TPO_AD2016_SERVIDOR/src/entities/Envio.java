package entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table (name = "Envios")
public class Envio {
	
	@Id
	@GeneratedValue
	@Column (nullable = false)
	private int idEnvio;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date fechaSalida;
	
	@Column (columnDefinition = "date", nullable = true)
	private Date fechaLlegada;
	
	@Column (columnDefinition = "bit", nullable = true)
	private boolean cumpleCondicionesCarga;
	
	@Column (columnDefinition = "varchar(50)", nullable = true)
	private String estado;
	
	@OneToOne (cascade = CascadeType.ALL)
	@JoinColumn (name = "idPedido")
	private Pedido envio;
	
	@Column (nullable = true)
	private int prioridad;
	
	public Envio() {
		
	}

	public int getIdEnvio() {
		return idEnvio;
	}

	public void setIdEnvio(int idEnvio) {
		this.idEnvio = idEnvio;
	}

	public Date getFechaSalida() {
		return fechaSalida;
	}

	public void setFechaSalida(Date fechaSalida) {
		this.fechaSalida = fechaSalida;
	}

	public Date getFechaLlegada() {
		return fechaLlegada;
	}

	public void setFechaLlegada(Date fechaLlegada) {
		this.fechaLlegada = fechaLlegada;
	}

	public boolean isCumpleCondicionesCarga() {
		return cumpleCondicionesCarga;
	}

	public void setCumpleCondicionesCarga(boolean cumpleCondicionesCarga) {
		this.cumpleCondicionesCarga = cumpleCondicionesCarga;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Pedido getEnvio() {
		return envio;
	}

	public void setEnvio(Pedido envio) {
		this.envio = envio;
	}

	public int getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}
}
