package entities;

import javax.persistence.*;

@Entity
@Table (name= "Remitos")

public class Remito {

	@Id
	@GeneratedValue
	@Column (nullable = false)
	private int idRemito;
	
	@OneToOne
	@JoinColumn (name = "idPedido")
	private Pedido pedido;
	
	public Remito(){
	}

	public int getIdRemito() {
		return idRemito;
	}

	public void setIdRemito(int idRemito) {
		this.idRemito = idRemito;
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}
}
