package dto;

import java.sql.Date;




public class VehiculoDTO {


		private int idVehiculo;
		private String tipo;
		private float volumen;
		private float peso;
		private float ancho;
		private float alto;
		private float profundidad;
		private float tara;
		private int kilometraje;
		private String estado;
		private String especificacion;
		private Date fechaUltimoControl;
		private PlanDeMantenimientoDTO planDeMantenimiento;
		public int getIdVehiculo() {
			return idVehiculo;
		}
		public void setIdVehiculo(int idVehiculo) {
			this.idVehiculo = idVehiculo;
		}
		public String getTipo() {
			return tipo;
		}
		public void setTipo(String tipo) {
			this.tipo = tipo;
		}
		public float getVolumen() {
			return volumen;
		}
		public void setVolumen(float volumen) {
			this.volumen = volumen;
		}
		public float getPeso() {
			return peso;
		}
		public void setPeso(float peso) {
			this.peso = peso;
		}
		public float getAncho() {
			return ancho;
		}
		public void setAncho(float ancho) {
			this.ancho = ancho;
		}
		public float getAlto() {
			return alto;
		}
		public void setAlto(float alto) {
			this.alto = alto;
		}
		public float getProfundidad() {
			return profundidad;
		}
		public void setProfundidad(float profundidad) {
			this.profundidad = profundidad;
		}
		public float getTara() {
			return tara;
		}
		public void setTara(float tara) {
			this.tara = tara;
		}
		public int getKilometraje() {
			return kilometraje;
		}
		public void setKilometraje(int kilometraje) {
			this.kilometraje = kilometraje;
		}
		public String getEstado() {
			return estado;
		}
		public void setEstado(String estado) {
			this.estado = estado;
		}
		public String getEspecificacion() {
			return especificacion;
		}
		public void setEspecificacion(String especificacion) {
			this.especificacion = especificacion;
		}
		public Date getFechaUltimoControl() {
			return fechaUltimoControl;
		}
		public void setFechaUltimoControl(Date fechaUltimoControl) {
			this.fechaUltimoControl = fechaUltimoControl;
		}
		public PlanDeMantenimientoDTO getPlanDeMantenimiento() {
			return planDeMantenimiento;
		}
		public void setPlanDeMantenimiento(PlanDeMantenimientoDTO planDeMantenimiento) {
			this.planDeMantenimiento = planDeMantenimiento;
		}
		

}
