package dto;

import java.io.Serializable;

public class FacturaDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int idFactura;
	private int idPEdido;
	private float precio;
	
	public FacturaDTO(){
	}

	public int getIdFactura() {
		return idFactura;
	}

	public void setIdFactura(int idFactura) {
		this.idFactura = idFactura;
	}

	public int getIdPEdido() {
		return idPEdido;
	}

	public void setIdPEdido(int idPEdido) {
		this.idPEdido = idPEdido;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
