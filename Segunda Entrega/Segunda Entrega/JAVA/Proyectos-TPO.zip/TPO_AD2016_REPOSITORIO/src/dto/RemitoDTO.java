package dto;

import java.io.Serializable;

public class RemitoDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int idRemito;
	private int idPEdido;
	
	public RemitoDTO(){
	}

	public int getIdRemito() {
		return idRemito;
	}

	public void setIdRemito(int idRemito) {
		this.idRemito = idRemito;
	}

	public int getIdPEdido() {
		return idPEdido;
	}

	public void setIdPEdido(int idPEdido) {
		this.idPEdido = idPEdido;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
		

}
