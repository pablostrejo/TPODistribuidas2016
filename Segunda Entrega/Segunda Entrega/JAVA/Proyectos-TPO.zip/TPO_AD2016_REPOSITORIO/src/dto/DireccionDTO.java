package dto;

import java.io.Serializable;

public class DireccionDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	private String calle;
	private int numero;
	private int piso;
	private String departamento;
	private String CP;
	
	public DireccionDTO(){
	}
	
	public String getCalle() {
		return calle;
	}
	public void setCalle(String calle) {
		this.calle = calle;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getPiso() {
		return piso;
	}
	public void setPiso(int piso) {
		this.piso = piso;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public String getCP() {
		return CP;
	}
	public void setCP(String cP) {
		CP = cP;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
}
