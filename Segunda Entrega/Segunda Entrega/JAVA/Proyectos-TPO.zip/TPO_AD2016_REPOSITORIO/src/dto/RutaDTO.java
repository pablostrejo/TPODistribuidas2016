package dto;

import java.io.Serializable;
import java.util.List;

public class RutaDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4870172584415686445L;
	private int idRuta;
	private List<TrayectoDTO> trayectos;
	private float precio;
	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}
	public int getIdRuta() {
		return idRuta;
	}
	public void setIdRuta(int idRuta) {
		this.idRuta = idRuta;
	}
	public List<TrayectoDTO> getTrayectos() {
		return trayectos;
	}
	public void setTrayectos(List<TrayectoDTO> trayectos) {
		this.trayectos = trayectos;
	}
	
	
}
