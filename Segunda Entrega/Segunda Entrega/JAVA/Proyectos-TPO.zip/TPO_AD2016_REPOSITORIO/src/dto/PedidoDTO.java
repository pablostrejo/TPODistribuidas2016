package dto;


import java.io.Serializable;
import java.sql.Date;
import java.util.List;

public class PedidoDTO implements Serializable{
		
	private static final long serialVersionUID = 1L;
	
	private int idPedido;
	private DireccionDTO direccionCarga;
	private DireccionDTO direccionDestino;
	private Date fechaCarga;
	private Date horaInicio;
	private Date horaFin;
	private Date fechaMaxima;
	private List<HabilitadoDTO> habilitados;
	private List<CargaDTO> cargas;
	private float precio;
	private String sucursalDestino;
	private boolean solicitaTransporteDirecto;
	private boolean solicitaAvionetaParticular;
	
	public PedidoDTO(){
	}

	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}

	public DireccionDTO getDireccionCarga() {
		return direccionCarga;
	}

	public void setDireccionCarga(DireccionDTO direccionCarga) {
		this.direccionCarga = direccionCarga;
	}

	public DireccionDTO getDireccionDestino() {
		return direccionDestino;
	}

	public void setDireccionDestino(DireccionDTO direccionDestino) {
		this.direccionDestino = direccionDestino;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public Date getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Date horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Date getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public Date getFechaMaxima() {
		return fechaMaxima;
	}

	public void setFechaMaxima(Date fechaMaxima) {
		this.fechaMaxima = fechaMaxima;
	}

	public List<HabilitadoDTO> getHabilitados() {
		return habilitados;
	}

	public void setHabilitados(List<HabilitadoDTO> habilitados) {
		this.habilitados = habilitados;
	}

	public List<CargaDTO> getCargas() {
		return cargas;
	}

	public void setCargas(List<CargaDTO> cargas) {
		this.cargas = cargas;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public String getSucursalDestino() {
		return sucursalDestino;
	}

	public void setSucursalDestino(String sucursalDestino) {
		this.sucursalDestino = sucursalDestino;
	}

	public boolean isSolicitaTransporteDirecto() {
		return solicitaTransporteDirecto;
	}

	public void setSolicitaTransporteDirecto(boolean solicitaTransporteDirecto) {
		this.solicitaTransporteDirecto = solicitaTransporteDirecto;
	}

	public boolean isSolicitaAvionetaParticular() {
		return solicitaAvionetaParticular;
	}

	public void setSolicitaAvionetaParticular(boolean solicitaAvionetaParticular) {
		this.solicitaAvionetaParticular = solicitaAvionetaParticular;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
