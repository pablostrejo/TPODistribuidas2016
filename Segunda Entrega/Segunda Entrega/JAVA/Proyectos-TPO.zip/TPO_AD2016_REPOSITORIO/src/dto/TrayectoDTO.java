package dto;

import java.io.Serializable;
import java.sql.Date;

public class TrayectoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8276738872174890036L;
	private int idTrayecto;
	private SucursalDTO sucursalOrigen;
	private SucursalDTO sucursalDestino;
	private Date tiempo;
	private int km;
	private float precio;
	public int getIdTrayecto() {
		return idTrayecto;
	}
	public void setIdTrayecto(int idTrayecto) {
		this.idTrayecto = idTrayecto;
	}
	public SucursalDTO getSucursalOrigen() {
		return sucursalOrigen;
	}
	public void setSucursalOrigen(SucursalDTO sucursalOrigen) {
		this.sucursalOrigen = sucursalOrigen;
	}
	public SucursalDTO getSucursalDestino() {
		return sucursalDestino;
	}
	public void setSucursalDestino(SucursalDTO sucursalDestino) {
		this.sucursalDestino = sucursalDestino;
	}
	public Date getTiempo() {
		return tiempo;
	}
	public void setTiempo(Date tiempo) {
		this.tiempo = tiempo;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}
	
}
