package rmi;

import java.rmi.Remote;

public interface RemoteInterface extends Remote {
	
	
}

